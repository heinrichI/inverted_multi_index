Multi-index locality-sensitive hashing
======================================

An exercise trying to implement fast locality-sensive hashing searches in Hamming space via [this article](https://engineering.eventbrite.com/multi-index-locality-sensitive-hashing-for-fun-and-profit/) and [this paper](http://www.cs.toronto.edu/~norouzi/research/papers/multi_index_hashing.pdf). Work in progress.